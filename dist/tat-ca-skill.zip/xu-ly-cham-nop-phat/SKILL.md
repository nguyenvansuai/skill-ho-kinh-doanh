---
name: xu-ly-cham-nop-phat
description: Xử lý khi hộ kinh doanh, cá nhân kinh doanh trễ hạn hoặc khai sai thuế — tính tiền chậm nộp 0,03%/ngày, ước khung phạt chậm nộp tờ khai, phân biệt vi phạm thủ tục với trốn thuế (mốc 90 ngày), khai bổ sung trong 5 năm để không bị phạt khai sai, gia hạn và miễn khi bất khả kháng, đọc thông báo/quyết định của cơ quan thuế và soạn văn bản giải trình. Dùng khi người dùng nói "quên nộp tờ khai", "nộp thuế trễ", "bị phạt bao nhiêu", "tiền chậm nộp", "khai sai doanh thu", "khai bổ sung", "nhận thông báo của chi cục thuế", "giải trình với thuế".
---

# Xử lý chậm nộp, khai sai, phạt thuế

Đọc `references/nguyen-tac-chung.md`, `references/quy-dinh-thue-hkd-2026.md` và `references/che-tai.md`.

Thái độ: bình tĩnh, nói rõ hậu quả thật, ưu tiên **việc làm ngay để giảm thiệt hại**. Không dọa, không hứa "không sao".

## 1. Xác định tình huống (hỏi tối đa 2 câu)

| Tình huống | Cần biết |
|---|---|
| A. Chưa nộp tờ khai, đã quá hạn | Kỳ nào, hạn gốc, có phát sinh thuế không, số thuế |
| B. Đã khai nhưng chưa nộp tiền / nộp trễ | Số thuế, hạn, ngày định nộp |
| C. Phát hiện khai sai (thiếu doanh thu, sai ngành) | Kỳ sai, số chênh, cơ quan thuế đã có quyết định kiểm tra chưa |
| D. Nhận thông báo, quyết định của cơ quan thuế | Ảnh/bản chụp văn bản (nhắc người dùng che mã số thuế, số tài khoản nếu muốn) |
| E. Gặp thiên tai, hỏa hoạn, tai nạn, ốm nặng | Thời điểm, thiệt hại, giấy tờ chứng minh |

Hạn gốc rơi vào ngày nghỉ thì đã lùi sang ngày làm việc kế tiếp (skill `lich-thue-hkd`) – dùng hạn đã lùi khi tính.

## 2. Tính bằng script

```bash
python3 scripts/tinh_cham_nop.py tien --so-thue 15000000 --han 2026-07-31 --ngay-nop 2026-11-05
python3 scripts/tinh_cham_nop.py ho-so --han 2026-07-31 --ngay-nop 2026-11-05 --co-thue --da-nop-du --so-thue-to-khai 15000000
```

## 3. Việc nên làm theo tình huống

- **A.** Nộp tờ khai **ngay**; có thuế thì nộp luôn thuế + tiền chậm nộp. Nhấn mạnh mốc **90 ngày**: quá 90 ngày, có thuế mà chưa nộp đủ trước khi cơ quan thuế kiểm tra → có thể bị coi là **trốn thuế** (phạt 1–3 lần); đã nộp đủ trước đó → chỉ phạt thủ tục (Luật 108/2025 Đ.45 k.4 điểm a, l).
- **B.** Nộp sớm nhất có thể; tiền chậm nộp tính theo ngày.
- **C.** Khai bổ sung (tờ khai đánh dấu "bổ sung lần thứ…") và **tự nộp đủ** trước khi cơ quan thuế công bố quyết định kiểm tra → không bị phạt khai sai 20%, chỉ nộp tiền chậm nộp (Đ.44 k.2 điểm a; Đ.12 k.5). Không tự hủy tờ khai đã được chấp nhận.
- **D.** Đọc văn bản theo mục 6 của `references/che-tai.md`: tóm tắt cơ quan thuế yêu cầu gì, số tiền từng khoản, **hạn**; kiểm tra số tiền chậm nộp bằng script; nếu thấy sai → soạn **văn bản giải trình** (khung bên dưới); nếu không đồng ý quyết định → nêu quyền khiếu nại (Đ.41) và khuyên hỏi luật sư/đại lý thuế.
- **E.** Gia hạn nộp hồ sơ tối đa 30/60 ngày (Đ.12 k.4); miễn tiền chậm nộp (Đ.16 k.5) và miễn phạt trong giới hạn thiệt hại (Đ.44 k.9) khi bất khả kháng. Liệt kê giấy tờ chứng minh cần gom; thủ tục cụ thể **[cần kiểm tra]** với cơ quan thuế.

**Khung văn bản giải trình** (điền số liệu của người dùng, để trống chỗ chưa biết): kính gửi (cơ quan thuế quản lý) · người nộp thuế, mã số thuế · căn cứ văn bản nhận được (số, ngày) · nội dung giải trình từng điểm, kèm số liệu, chứng từ · đề nghị · danh sách tài liệu kèm theo · ngày, ký.

## 4. Đầu ra

1. Tình huống của anh/chị (một câu) + hậu quả ước tính: tiền chậm nộp, khung phạt (hộ = 1/2 tổ chức), căn cứ.
2. **Việc cần làm ngay** (đánh số, có hạn) – nộp ở đâu (skill `khai-bao-thue-hkd` cho bước bấm).
3. Văn bản giải trình nếu cần.
4. Ghi rõ: khung phạt theo NĐ 125/2020 và các nghị định sửa đổi **[cần kiểm tra văn bản hiện hành]**; số chính thức theo quyết định của cơ quan thuế.
5. Câu chốt: "Đối chiếu quy định hiện hành và hỏi cơ quan thuế quản lý; vụ việc phức tạp nên hỏi đại lý thuế hoặc luật sư."

Không được: khuyên che giấu doanh thu, sửa sổ sách lùi ngày, hủy hóa đơn để né thuế.

<!-- KET-NOI:BAT-DAU (sinh tự động từ scripts/ket_noi.json – sửa ở đó rồi chạy build) -->
## Kết nối ứng dụng

Connector dùng cho skill này: **Gmail** · **Google Drive** · **Google Calendar**. Đọc quy tắc trong `references/ket-noi.md` trước khi dùng.

1. Tìm thông báo của cơ quan thuế (tiền chậm nộp, quyết định xử phạt) trong email hoặc Drive để tính lại đúng số ngày.
2. Tạo nhắc hạn nộp tiền phạt, hạn giải trình trên lịch; lưu bảng tính vào Drive.

**Khi chưa kết nối:** làm đủ phần soạn thảo, tính toán; đưa nội dung sẵn để người dùng tự dán vào email, lịch, thư mục; nhắc **một lần** cách bật connector, không dừng việc chỉ vì chưa kết nối.
<!-- KET-NOI:KET-THUC -->
