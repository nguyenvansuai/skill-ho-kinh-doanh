---
name: doi-soat-doanh-thu
description: Đối soát sổ doanh thu hộ kinh doanh với sao kê ngân hàng, ví MoMo và báo cáo doanh thu sàn (Shopee, TikTok Shop, Lazada) — tìm tiền vào tài khoản mà sổ chưa ghi, khoản sổ ghi chuyển khoản mà sao kê không có, doanh thu sàn trên sổ lệch báo cáo sàn; loại tiền nội bộ, tiền vay, tiền sàn chuyển về; cộng theo quý, lũy kế, so mốc 1 tỷ, 3 tỷ và báo trước quý sẽ vượt. Chưa có sổ thì dựng doanh thu từ sao kê. Dùng khi người dùng nói "đối soát", "đối soát sổ quý này", "sổ có khớp sao kê không", "sao kê", "cộng doanh thu theo quý", "doanh thu đã vượt 1 tỷ chưa".
---

# Đối soát doanh thu

Đọc `references/nguyen-tac-chung.md` và `references/quy-dinh-thue-hkd-2026.md` (mục 2, 3, 3a).

Mục tiêu: **sổ doanh thu phải khớp với dòng tiền** mà ngân hàng, ví, sàn ghi nhận – vì cơ quan thuế có dữ liệu từ các nguồn này. Đối soát để tìm và sửa chỗ lệch **trước** khi bị hỏi, rồi biết chính xác mình đang ở mốc nào.

## 1. Chọn cách làm

| Người dùng có | Cách |
|---|---|
| Sổ doanh thu (Excel/CSV từ skill `ghi-so-hkd`) + sao kê + báo cáo sàn | **A. Đối chiếu sổ** (khuyến nghị, làm cuối mỗi quý) |
| Chỉ có sao kê, báo cáo sàn, chưa có sổ | **B. Dựng doanh thu từ sao kê**, rồi khuyên lập sổ bằng `ghi-so-hkd` |

Nhắc người dùng che số tài khoản đầy đủ trước khi gửi. Sao kê PDF nhiều trang dễ đọc sót → khuyên xuất Excel.

## 2. Cách A – Đối chiếu sổ với sao kê, báo cáo sàn

```bash
python3 scripts/doi_chieu_so.py so.csv sao_ke.xlsx --cot-ngay "Ngày GD" --cot-noi-dung "Nội dung" --cot-tien "Ghi có" \
  --bao-cao-san shopee.csv --cot-ngay-san "Ngày" --cot-tien-san "Doanh thu" --tu 01/07/2026 --den 30/09/2026
```

Sổ cần cột `ngay, dien_giai, so_tien`, diễn giải mở đầu bằng mã nguồn `[TM] [CK] [MoMo] [Sàn]`. Sổ Excel → đọc tab S1a/S2a, chuyển sang CSV trước.

Script tự:
- Loại khỏi sao kê: chuyển nội bộ, vay/trả nợ, **tiền sàn chuyển về** (doanh thu sàn so theo báo cáo sàn).
- Khớp từng dòng sổ `[CK]`/`[MoMo]` với giao dịch sao kê cùng số tiền, lệch ngày tối đa 3 ngày.
- Liệt kê 3 loại lệch:

| Loại lệch | Gợi ý xử lý (người dùng quyết định) |
|---|---|
| Tiền vào tài khoản/ví, **sổ chưa ghi** | Tiền bán hàng → bổ sung vào sổ; không rõ → hỏi, **không tự cộng** |
| Sổ ghi chuyển khoản/ví, **sao kê không có** | Khách trả tiền mặt → đổi nguồn `[TM]`; ghi trùng → xóa dòng |
| Doanh thu sàn trên sổ **khác báo cáo sàn** | Thiếu đơn → bổ sung `[Sàn]`; thừa → kiểm tra đơn hủy, hoàn |

Sau khi người dùng xác nhận: sửa sổ (CSV → `ghi-so-hkd/scripts/tao_so_doanh_thu.py`), cộng lại theo quý và lũy kế **từ sổ đã sửa**.

## 3. Cách B – Chưa có sổ: dựng doanh thu từ sao kê

```bash
python3 scripts/doi_soat.py sao_ke.xlsx --cot-ngay "Ngày GD" --cot-noi-dung "Nội dung" --cot-tien "Ghi có" \
  --bao-cao-san doanh_thu_san.csv --cot-ngay-san "Ngày" --cot-tien-san "Doanh thu" --ra ket_qua.xlsx
```

Phân loại: tiền bán hàng · tiền sàn chuyển về · chuyển nội bộ · vay/trả nợ · chưa rõ (không tự xếp vào doanh thu). Doanh thu sàn lấy theo báo cáo sàn. Lưu ý: sao kê **không có tiền mặt** → con số này thiếu phần bán tiền mặt; khuyên lập sổ đủ 3 nguồn.

## 4. Đầu ra

1. **Bảng chênh lệch** (cách A) hoặc danh sách giao dịch **Chưa rõ** (cách B), mỗi dòng có gợi ý xử lý; hỏi người dùng xác nhận.
2. Bảng doanh thu theo quý và lũy kế (sau khi sửa), ghi "Đã kiểm tra phép tính".
3. Trạng thái so mốc: đã vượt 1 tỷ chưa, từ quý nào; còn bao nhiêu đến mốc; dự báo quý vượt theo tốc độ quý gần nhất.
4. **Việc cần làm** theo trạng thái: chưa vượt 1 tỷ → danh sách A; đã vượt hoặc dự báo vượt trong năm → danh sách B (mục 3a của `references/quy-dinh-thue-hkd-2026.md`), giữ nguyên căn cứ.
5. Câu chốt: "Đối chiếu quy định hiện hành và hỏi cơ quan thuế quản lý trước khi thực hiện."

Người dùng chỉ cần gửi file và nói "đối soát sổ quý 3 giúp tôi"; skill tự chọn cách, khớp, liệt kê chỗ lệch, hỏi lại, rồi cộng và so mốc.

<!-- KET-NOI:BAT-DAU (sinh tự động từ scripts/ket_noi.json – sửa ở đó rồi chạy build) -->
## Kết nối ứng dụng

Connector dùng cho skill này: **Gmail** · **Google Drive**. Đọc quy tắc trong `references/ket-noi.md` trước khi dùng.

1. Lấy sao kê ngân hàng, ví MoMo, báo cáo thanh toán của sàn trong email hoặc Drive đúng kỳ cần đối soát.
2. Lưu bảng đối soát và danh sách khoản chưa khớp vào Drive.

**Khi chưa kết nối:** làm đủ phần soạn thảo, tính toán; đưa nội dung sẵn để người dùng tự dán vào email, lịch, thư mục; nhắc **một lần** cách bật connector, không dừng việc chỉ vì chưa kết nối.
<!-- KET-NOI:KET-THUC -->
